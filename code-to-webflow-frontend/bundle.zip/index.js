// ============================================================
// Code to Webflow — Designer Extension
// Paste AI-generated JSON to build Webflow element trees
// ============================================================
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// ------------------------------------
// V1 Legacy Safety Shim
// v2 JSON from the backend is already fully normalized.
// This shim handles any old (v1) files that may still be pasted manually.
// ------------------------------------
/**
 * Expands CSS shorthands into their constituent parts for the Webflow API.
 * This ensures properties like 'border-bottom' or 'padding' hit the native panels.
 */
function expandProperties(properties) {
    const expanded = {};
    for (let [key, val] of Object.entries(properties)) {
        if (val === null || val === undefined)
            continue;
        const value = String(val).trim();
        // 1. Padding/Margin expansion
        if (key === "padding" || key === "margin") {
            const parts = value.split(/\s+/);
            if (parts.length === 1) {
                expanded[`${key}-top`] = parts[0];
                expanded[`${key}-right`] = parts[0];
                expanded[`${key}-bottom`] = parts[0];
                expanded[`${key}-left`] = parts[0];
            }
            else if (parts.length === 2) {
                expanded[`${key}-top`] = parts[0];
                expanded[`${key}-bottom`] = parts[0];
                expanded[`${key}-right`] = parts[1];
                expanded[`${key}-left`] = parts[1];
            }
            else if (parts.length === 3) {
                expanded[`${key}-top`] = parts[0];
                expanded[`${key}-right`] = parts[1];
                expanded[`${key}-left`] = parts[1];
                expanded[`${key}-bottom`] = parts[2];
            }
            else if (parts.length === 4) {
                expanded[`${key}-top`] = parts[0];
                expanded[`${key}-right`] = parts[1];
                expanded[`${key}-bottom`] = parts[2];
                expanded[`${key}-left`] = parts[3];
            }
            continue;
        }
        // 2. Border expansion (e.g. border-bottom: 1px solid red)
        if (key.match(/^border-(top|right|bottom|left)$/) || key === "border") {
            const prefix = key === "border" ? "border" : key;
            const parts = value.split(/\s+/);
            // Simple parser for "1px solid red" or "1px solid var(--color)"
            let width, style, color;
            for (const part of parts) {
                if (part.match(/^(solid|dashed|dotted|double|none|hidden)$/)) {
                    style = part;
                }
                else if (part.match(/^(thin|medium|thick|[0-9.]+(px|em|rem|%|vh|vw|pt))$/) ||
                    part === "0") {
                    width = part;
                }
                else {
                    // If it doesn't match a style or a known unit, treat it as a color (includes vars)
                    color = part;
                }
            }
            if (key === "border") {
                const sides = ["top", "right", "bottom", "left"];
                for (const side of sides) {
                    if (width)
                        expanded[`border-${side}-width`] = width;
                    if (style)
                        expanded[`border-${side}-style`] = style;
                    if (color)
                        expanded[`border-${side}-color`] = color;
                }
            }
            else {
                if (width)
                    expanded[`${prefix}-width`] = width;
                if (style)
                    expanded[`${prefix}-style`] = style;
                if (color)
                    expanded[`${prefix}-color`] = color;
            }
            continue;
        }
        // 3. Gap expansion (legacy support & safety)
        if (key === "gap") {
            const parts = value.split(/\s+/);
            expanded["row-gap"] = parts[0];
            expanded["column-gap"] = parts[1] || parts[0];
            continue;
        }
        // 4. Background shorthand (simple color check)
        if (key === "background") {
            const isColor = /^(#|rgb|hsl|[a-zA-Z]+$)/.test(value) &&
                !value.includes("gradient(") &&
                !value.includes("url(");
            expanded[isColor ? "background-color" : "background-image"] = value;
            continue;
        }
        // 5. Transition expansion
        if (key === "transition") {
            const chunks = value.split(/,(?![^()]*\))/).map((s) => s.trim());
            const properties = [];
            const durations = [];
            const timingFunctions = [];
            const delays = [];
            for (const chunk of chunks) {
                const tokens = chunk
                    .split(/\s+(?![^()]*\))/)
                    .map((s) => s.trim())
                    .filter(Boolean);
                let prop = "all";
                let dur = "0s";
                let timing = "ease";
                let del = "0s";
                let timeCount = 0;
                for (const token of tokens) {
                    if (/^\.?\d+(s|ms)$/.test(token) ||
                        /^\d+\.?\d*(s|ms)$/.test(token)) {
                        if (timeCount === 0) {
                            dur = token;
                            timeCount++;
                        }
                        else {
                            del = token;
                        }
                    }
                    else if (/^(ease|linear|step|cubic-bezier|var\()/.test(token)) {
                        timing = token;
                    }
                    else {
                        prop = token;
                    }
                }
                const toMs = (val) => {
                    if (val.endsWith("ms"))
                        return val;
                    if (val.endsWith("s")) {
                        const num = parseFloat(val);
                        return isNaN(num) ? val : `${Math.round(num * 1000)}ms`;
                    }
                    return val;
                };
                properties.push(prop);
                durations.push(toMs(dur));
                timingFunctions.push(timing);
                delays.push(toMs(del));
            }
            expanded["transition-property"] = properties.join(", ");
            expanded["transition-duration"] = durations.join(", ");
            expanded["transition-timing-function"] = timingFunctions.join(", ");
            if (delays.some((d) => d !== "0s" && d !== "0ms")) {
                expanded["transition-delay"] = delays.join(", ");
            }
            continue;
        }
        expanded[key] = val;
    }
    return expanded;
}
function normalizePropertiesLegacy(properties) {
    const out = {};
    for (const [rawKey, rawValue] of Object.entries(properties)) {
        const val = typeof rawValue === "string"
            ? rawValue.replace(/\s+/g, " ").trim()
            : String(rawValue);
        let key = rawKey.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
        if (key.startsWith("--"))
            continue;
        if (key.startsWith("-webkit-") ||
            key.startsWith("-moz-") ||
            key.startsWith("-ms-") ||
            key.startsWith("-o-")) {
            const std = key.replace(/^-(webkit|moz|ms|o)-/, "");
            if (std === "backdrop-filter") {
                key = std;
            }
            else {
                continue;
            }
        }
        out[key] = val;
    }
    // Run through expansion to handle shorthands
    return expandProperties(out);
}
// ------------------------------------
// Helpers
// ------------------------------------
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
function handleStyleError(err, property) {
    var _a;
    const causeTag = (_a = err === null || err === void 0 ? void 0 : err.cause) === null || _a === void 0 ? void 0 : _a.tag;
    const message = (err === null || err === void 0 ? void 0 : err.message) || "";
    console.error(`Cause: ${causeTag}`);
    console.error(`Message: ${message}`);
    switch (causeTag) {
        case "InvalidStyle":
            webflow.notify({
                type: "Error",
                message: "The style is invalid or not recognized",
            });
            break;
        case "InvalidStyleProperty":
            console.warn(`Property ${property} is invalid or not applicable.`);
            break;
        case "ResourceMissing":
            webflow.notify({
                type: "Error",
                message: "The style resource is missing.",
            });
            break;
        default:
            if (message.toLowerCase().includes("conflict")) {
                // Conflict errors are handled by retry logic, but if they persist:
                webflow.notify({
                    type: "Error",
                    message: "Style conflict detected in the store. Try again.",
                });
            }
            else {
                webflow.notify({
                    type: "Error",
                    message: "An error occurred with styles.",
                });
            }
    }
}
// Cache for created/existing variables, bindings, and raw values
// Stores: { variable: Variable, binding: string, rawValue: any, type: string }
const variableCache = new Map();
function withTimeout(promise, timeoutMs, name) {
    return __awaiter(this, void 0, void 0, function* () {
        let timeoutHandle;
        const timeoutPromise = new Promise((_, reject) => {
            timeoutHandle = setTimeout(() => reject(new Error(`Timeout: ${name} took too long (> ${timeoutMs}ms)`)), timeoutMs);
        });
        try {
            return yield Promise.race([promise, timeoutPromise]);
        }
        finally {
            clearTimeout(timeoutHandle);
        }
    });
}
/**
 * Normalizes CSS pseudo-states to Webflow-supported ones.
 * Webflow only supports a specific list; unsupported ones (like nth-child(4n)) cause API errors.
 */
function normalizePseudo(rawPseudo) {
    if (!rawPseudo || rawPseudo === "noPseudo")
        return "noPseudo";
    // List of pseudo-states natively supported by the Webflow Designer API
    const supported = [
        "nth-child(odd)",
        "nth-child(even)",
        "first-child",
        "last-child",
        "disabled",
        "hover",
        "active",
        "pressed",
        "visited",
        "focus",
        "focus-visible",
        "focus-within",
        "placeholder",
        "empty",
        "before",
        "after",
        "lang",
        "data",
    ];
    // Exact match check
    if (supported.includes(rawPseudo))
        return rawPseudo;
    const lower = rawPseudo.toLowerCase();
    // 1. Hover/Focus variants
    if (lower.includes("hover"))
        return "hover";
    if (lower.includes("focus-visible"))
        return "focus-visible";
    if (lower.includes("focus-within"))
        return "focus-within";
    if (lower.includes("focus"))
        return "focus";
    // 2. Child variants
    if (lower.includes("first-child"))
        return "first-child";
    if (lower.includes("last-child"))
        return "last-child";
    // 3. Nth-child logic (Webflow only supports odd/even)
    if (lower.includes("nth-child")) {
        if (lower.includes("even") || lower.includes("(2n)"))
            return "nth-child(even)";
        if (lower.includes("odd"))
            return "nth-child(odd)";
        if (lower.includes("(1)"))
            return "first-child";
        // Default to last-child for other unsupported nth-child (like 4n) as requested
        return "last-child";
    }
    return "noPseudo";
}
function applyStyleProperties(style_1, properties_1, options_1) {
    return __awaiter(this, arguments, void 0, function* (style, properties, options, isLegacy = false) {
        const styleName = yield style.getName();
        const pseudo = normalizePseudo(options === null || options === void 0 ? void 0 : options.pseudo);
        const styleLabel = pseudo !== "noPseudo"
            ? `.${styleName}:${pseudo}`
            : `.${styleName}`;
        // 1. Run normalization/expansion
        const props = isLegacy
            ? normalizePropertiesLegacy(properties)
            : expandProperties(properties);
        // 2. Resolve var() references to Webflow native Variable objects (purple pills).
        const resolvedProperties = {};
        for (const [prop, val] of Object.entries(props)) {
            let valueToSet = val;
            if (typeof val === "string" && val.includes("var(")) {
                const simpleVarMatch = val.trim().match(/^var\((--[^)]+)\)$/);
                if (prop.startsWith("transition") || prop.startsWith("transform")) {
                    // Webflow strictly bans 'transition' from custom properties and cannot handle var() natively here.
                    // It's safer to completely inline the raw values so complex properties actually work without crashing the API.
                    valueToSet = val.replace(/var\((--[^)]+)\)/g, (match, varName) => {
                        const cached = variableCache.get(varName);
                        if (cached && cached.rawValue != null) {
                            const raw = cached.rawValue;
                            if (typeof raw === "string" ||
                                typeof raw === "number")
                                return String(raw);
                            if (raw.value !== undefined && raw.unit)
                                return `${raw.value}${raw.unit}`;
                            if (raw.value !== undefined)
                                return String(raw.value);
                        }
                        return match;
                    });
                }
                else if (simpleVarMatch) {
                    const cached = variableCache.get(simpleVarMatch[1]);
                    if (cached && cached.variable) {
                        valueToSet = cached.variable;
                    }
                    else if (cached && cached.binding) {
                        valueToSet = cached.binding;
                    }
                }
                else {
                    valueToSet = val.replace(/var\((--[^)]+)\)/g, (match, varName) => {
                        const cached = variableCache.get(varName);
                        return cached && cached.cssName
                            ? `var(${cached.cssName})`
                            : match;
                    });
                }
            }
            resolvedProperties[prop] = valueToSet;
        }
        // 3. Build Webflow API options with cross-version compatibility for pseudo-states
        const bp = (options === null || options === void 0 ? void 0 : options.breakpointId) || "main";
        const wfOptions = {
            breakpointId: bp,
            breakpoint: bp, // Fallback for various API versions
            pseudoStateKey: pseudo,
            pseudo: pseudo, // Fallback for various API versions
        };
        // 4. Priority Sorting: Apply layout-defining properties first
        // This ensures 'position' is set before 'left/right' and 'display' before 'row-gap'
        const allEntries = Object.entries(resolvedProperties);
        const layoutProps = [
            "display",
            "position",
            "flex-direction",
            "grid-template-columns",
            "grid-template-rows",
        ];
        const priorityEntries = allEntries.filter(([k]) => layoutProps.includes(k));
        const remainingEntries = allEntries.filter(([k]) => !layoutProps.includes(k));
        const sortedEntries = [...priorityEntries, ...remainingEntries];
        // 5. Split into two tracks:
        //    - plainEntries: safe to batch via setProperties() (unless it's a pseudo-state)
        //    - varEntries: { variableId } objects — MUST be applied one-by-one via setProperty()
        //      Batching { variableId } objects in setProperties() causes IPC serialization timeouts.
        const plainEntries = sortedEntries.filter(([, v]) => typeof v !== "object" || v === null);
        const varEntries = sortedEntries.filter(([, v]) => typeof v === "object" && v !== null);
        // 6. Apply plain string properties
        // CRITICAL: Pseudo-states (like :hover) often hang with batched setProperties().
        // We use CHUNK_SIZE=1 (one-by-one) for pseudo-states to ensure stability.
        const CHUNK_SIZE = (options === null || options === void 0 ? void 0 : options.pseudo) ? 1 : 15;
        let success = true;
        for (let i = 0; i < plainEntries.length; i += CHUNK_SIZE) {
            const chunk = {};
            for (const [k, v] of plainEntries.slice(i, i + CHUNK_SIZE)) {
                chunk[k] = v;
            }
            const chunkProps = Object.keys(chunk).join(", ");
            log(`    → Applying chunk ${Math.floor(i / CHUNK_SIZE) + 1} (${chunkProps}) on ${styleLabel}...`);
            try {
                const setPromise = wfOptions
                    ? style.setProperties(chunk, wfOptions)
                    : style.setProperties(chunk);
                yield withTimeout(setPromise, 15000, `setProperties Chunk ${Math.floor(i / CHUNK_SIZE) + 1}`);
            }
            catch (err) {
                log(`    ✕ Chunk ${Math.floor(i / CHUNK_SIZE) + 1} failed for ${styleLabel}: ${err.message}`, "error");
                log(`    › Falling back to per-property for this chunk...`, "warn");
                success = false;
                for (const [prop, val] of Object.entries(chunk)) {
                    log(`      → Fallback: Applying ${prop} on ${styleLabel}...`);
                    try {
                        const p1 = wfOptions
                            ? style.setProperty(prop, val, wfOptions)
                            : style.setProperty(prop, val);
                        yield withTimeout(p1, 5000, `setProperty ${prop}`);
                    }
                    catch (e) {
                        log(`      ⚠ Plain fallback failed for ${prop} on ${styleLabel} (value: ${JSON.stringify(val)}): ${e.message}`, "error");
                    }
                }
            }
        }
        // 7. Apply variable bindings individually — never batch { variableId } objects
        for (const [prop, val] of varEntries) {
            log(`    → Applying variable ${prop} (value: ${JSON.stringify(val)}) on ${styleLabel}...`);
            try {
                const p = wfOptions
                    ? style.setProperty(prop, val, wfOptions)
                    : style.setProperty(prop, val);
                yield withTimeout(p, 5000, `setProperty ${prop}`);
            }
            catch (e) {
                log(`      ⚠ Native apply failed for ${prop} on ${styleLabel} (value: ${JSON.stringify(val)}): ${e.message}`, "error");
                success = false;
            }
        }
        return success;
    });
}
function applyGlobalStyles(globalStyles_1) {
    return __awaiter(this, arguments, void 0, function* (globalStyles, isLegacy = false) {
        var _a;
        // Only simple class selectors (no descendant/tag selectors with spaces).
        // Complex selectors were pre-resolved into node.inlineStyles by the backend.
        const classSelectors = Object.keys(globalStyles).filter((s) => s.startsWith(".") && !s.includes(" "));
        const total = classSelectors.length;
        log(`Applying ${total} global style${total !== 1 ? "s" : ""}...`);
        // Pre-fetch all existing styles into a Map — avoids 1 round-trip per class
        const existingStyleMap = new Map();
        try {
            const allStyles = yield webflow.getAllStyles();
            for (const s of allStyles) {
                existingStyleMap.set(yield s.getName(), s);
            }
            log(`Pre-loaded ${existingStyleMap.size} existing styles`);
        }
        catch (_) {
            // getAllStyles not available in this API version — falls back to per-class lookup
        }
        let done = 0;
        for (const selector of classSelectors) {
            const value = globalStyles[selector];
            // Pseudo state: ".class:hover" → pseudo = "hover"
            const [baseRef, rawPseudo] = selector.split(":");
            const pseudo = normalizePseudo(rawPseudo);
            const className = baseRef.substring(1);
            let style = (_a = existingStyleMap.get(className)) !== null && _a !== void 0 ? _a : (yield webflow.getStyleByName(className));
            if (!style) {
                try {
                    style = yield webflow.createStyle(className);
                }
                catch (e) {
                    log(`Skipped .${className}: ${e.message}`, "warn");
                    done++;
                    continue;
                }
            }
            if (style && value) {
                try {
                    // v2 JSON: value is always breakpoint-keyed { main: {…}, small: {…}, … }
                    // v1 legacy: detect by checking whether first value is an object
                    const isBreakpointKeyed = !isLegacy ||
                        (Object.keys(value).some((k) => [
                            "main",
                            "medium",
                            "small",
                            "tiny",
                            "large",
                            "xl",
                            "xxl",
                        ].includes(k)) &&
                            typeof Object.values(value)[0] === "object");
                    if (isBreakpointKeyed) {
                        for (const [bp, props] of Object.entries(value)) {
                            if (props && Object.keys(props).length > 0) {
                                yield applyStyleProperties(style, props, { breakpointId: bp, pseudo }, isLegacy);
                            }
                        }
                    }
                    else {
                        if (Object.keys(value).length > 0) {
                            yield applyStyleProperties(style, value, { pseudo }, isLegacy);
                        }
                    }
                }
                catch (err) {
                    log(`  Error applying .${className}: ${err.message}`, "error");
                }
            }
            done++;
            incrementProgress();
            if (done % 20 === 0 || done === total)
                log(`Progress: ${done} / ${total} styles applied`);
        }
        log("✓ All styles applied", "success");
    });
}
// ------------------------------------
// DOM refs (populated after DOMContentLoaded)
// ------------------------------------
let jsonTextarea;
let errorBox;
let buildBtn;
let btnLabel;
let spinner;
let fileInput;
let dropzone;
let fileInfo;
let fileNameDisplay;
let removeFileBtn;
let progressLog;
let uploadedPayload = null;
let currentProgress = 0;
let totalSteps = 0;
function updateProgressBar() {
    const progressFill = document.getElementById("progress-fill");
    const progressText = document.getElementById("progress-percentage");
    if (!progressFill || !progressText)
        return;
    const percentage = totalSteps > 0 ? Math.round((currentProgress / totalSteps) * 100) : 0;
    progressFill.style.width = `${Math.min(percentage, 100)}%`;
    progressText.textContent = `${Math.min(percentage, 100)}%`;
}
function log(message, level = "info") {
    console.log(`[${level.toUpperCase()}] ${message}`);
    // Minimal UI: only show warnings and errors in the log panel
    const isWarningOrError = level === "warn" || level === "error";
    if (!isWarningOrError || !progressLog)
        return;
    const logPanel = document.getElementById("progress-log");
    if (logPanel)
        logPanel.classList.add("has-errors");
    const entry = document.createElement("div");
    entry.className = `log-entry log-${level}`;
    const icons = {
        info: "›",
        success: "✓",
        warn: "⚠",
        error: "✕",
    };
    entry.innerHTML = `<span class="log-icon">${icons[level]}</span><span class="log-text" style="white-space: pre-wrap;">${message}</span>`;
    progressLog.appendChild(entry);
    window.requestAnimationFrame(() => {
        progressLog.scrollTop = progressLog.scrollHeight;
    });
}
function incrementProgress(amount = 1) {
    currentProgress += amount;
    updateProgressBar();
}
function clearLog() {
    if (progressLog)
        progressLog.innerHTML = "";
}
// ------------------------------------
// Initialization
// ------------------------------------
function init() {
    var _a;
    const app = document.getElementById("app");
    if (!app)
        return;
    app.innerHTML = `
    <div class="header">
      <div class="header-content">
        <div class="logo">
          <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
            <rect width="26" height="26" rx="7" fill="url(#logoGrad)"/>
            <path d="M7 9h12M7 13h12M7 17h7" stroke="white" stroke-width="2" stroke-linecap="round"/>
            <defs>
              <linearGradient id="logoGrad" x1="0" y1="0" x2="26" y2="26">
                <stop stop-color="#3B82F6"/>
                <stop offset="1" stop-color="#6366F1"/>
              </linearGradient>
            </defs>
          </svg>
          <span class="logo-text">Code to Webflow</span>
        </div>
      </div>
    </div>

    <div class="main">
      <p class="description">
        Select a target element in the Webflow Designer (e.g. Body), upload a JSON file or paste your generated JSON below.
      </p>

      <div class="file-upload-container">
        <div class="field-label">File Upload</div>
        <div id="dropzone" class="file-dropzone">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="17 8 12 3 7 8"/>
            <line x1="12" y1="3" x2="12" y2="15"/>
          </svg>
          <div class="file-dropzone-text">Click to upload or drag & drop</div>
          <div class="file-dropzone-subtext">webflow-site-structure.json</div>
          <input type="file" id="file-input" accept=".json">
        </div>
        <div id="file-info" class="file-info">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
            <polyline points="14 2 14 8 20 8"></polyline>
          </svg>
          <span id="file-name-display">filename.json</span>
          <div id="remove-file" class="remove-file">×</div>
        </div>
      </div>

      <div class="divider">
        <div class="divider-line"></div>
        <div class="divider-text">or</div>
        <div class="divider-line"></div>
      </div>

      <div>
        <div class="field-label">JSON Payload</div>
        <textarea
          id="json-input"
          class="json-textarea"
          placeholder='Paste JSON here...'
        ></textarea>
      </div>

      <div id="error-box" class="error-box"></div>

      <button id="build-btn" class="btn-build" disabled>
        <div id="spinner" class="spinner"></div>
        <span id="btn-label">Build Site</span>
      </button>

      <div id="progress-container" class="progress-container">
        <div class="progress-label-row">
          <span>Overall Progress</span>
          <span id="progress-percentage">0%</span>
        </div>
        <div class="progress-bar-bg">
          <div id="progress-fill" class="progress-bar-fill"></div>
        </div>
        <div id="progress-log" class="progress-log">
          <div class="progress-log-header">
            <span>Issues & Alerts</span>
            <button id="clear-log-btn" class="clear-log-btn" title="Clear log">Clear</button>
          </div>
          <div id="progress-log-entries" class="progress-log-entries"></div>
        </div>
      </div>
    </div>

    <div class="toast" id="toast"></div>
  `;
    // Cache DOM refs
    jsonTextarea = document.getElementById("json-input");
    errorBox = document.getElementById("error-box");
    buildBtn = document.getElementById("build-btn");
    btnLabel = document.getElementById("btn-label");
    spinner = document.getElementById("spinner");
    fileInput = document.getElementById("file-input");
    dropzone = document.getElementById("dropzone");
    fileInfo = document.getElementById("file-info");
    fileNameDisplay = document.getElementById("file-name-display");
    removeFileBtn = document.getElementById("remove-file");
    progressLog = document.getElementById("progress-log-entries");
    // Clear log button
    (_a = document.getElementById("clear-log-btn")) === null || _a === void 0 ? void 0 : _a.addEventListener("click", () => {
        clearLog();
        const logPanel = document.getElementById("progress-log");
        if (logPanel)
            logPanel.classList.remove("has-errors");
    });
    jsonTextarea.addEventListener("input", () => {
        if (jsonTextarea.value.trim().length > 0) {
            clearUploadedFile();
        }
        updateBuildButtonState();
        hideError();
    });
    buildBtn.addEventListener("click", handleBuild);
    setupFileUpload();
}
function updateBuildButtonState() {
    const hasText = jsonTextarea.value.trim().length > 0;
    const hasFile = !!uploadedPayload;
    buildBtn.disabled = !hasText && !hasFile;
}
function clearUploadedFile() {
    uploadedPayload = null;
    fileInput.value = "";
    fileInfo.classList.remove("show");
}
function setupFileUpload() {
    dropzone.addEventListener("click", () => fileInput.click());
    dropzone.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropzone.classList.add("dragover");
    });
    dropzone.addEventListener("dragleave", () => {
        dropzone.classList.remove("dragover");
    });
    dropzone.addEventListener("drop", (e) => {
        var _a;
        e.preventDefault();
        dropzone.classList.remove("dragover");
        const files = (_a = e.dataTransfer) === null || _a === void 0 ? void 0 : _a.files;
        if (files && files.length > 0) {
            handleFileSelect(files[0]);
        }
    });
    fileInput.addEventListener("change", (e) => {
        const files = e.target.files;
        if (files && files.length > 0) {
            handleFileSelect(files[0]);
        }
    });
    removeFileBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        clearUploadedFile();
        updateBuildButtonState();
    });
}
function handleFileSelect(file) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!file.name.endsWith(".json")) {
            showError("Please select a .json file.");
            return;
        }
        const reader = new FileReader();
        reader.onload = (e) => {
            var _a;
            try {
                const content = (_a = e.target) === null || _a === void 0 ? void 0 : _a.result;
                uploadedPayload = JSON.parse(content);
                // Update UI
                fileNameDisplay.textContent = file.name;
                fileInfo.classList.add("show");
                jsonTextarea.value = ""; // Clear textarea to avoid confusion
                updateBuildButtonState();
                hideError();
                showToast("File loaded successfully", "success");
            }
            catch (err) {
                showError("Failed to parse JSON file.");
                console.error(err);
            }
        };
        reader.readAsText(file);
    });
}
// ------------------------------------
// Build handler
// ------------------------------------
function handleBuild() {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        let payload;
        if (uploadedPayload) {
            payload = uploadedPayload;
        }
        else {
            const raw = jsonTextarea.value.trim();
            if (!raw)
                return;
            try {
                payload = JSON.parse(raw);
            }
            catch (_c) {
                showError("Invalid JSON — please check your input.");
                return;
            }
        }
        // Safety: If the user pasted an array of nodes directly at the root
        if (Array.isArray(payload)) {
            payload = {
                nodes: payload,
                __meta: { version: 1, normalized: false, complexSelectorsResolved: false }
            };
        }
        setLoading(true);
        hideError();
        clearLog();
        currentProgress = 0;
        totalSteps = 0;
        updateProgressBar();
        const progressContainer = document.getElementById("progress-container");
        if (progressContainer)
            progressContainer.classList.add("show");
        const logPanel = document.getElementById("progress-log");
        if (logPanel)
            logPanel.classList.remove("has-errors");
        log("--- START BUILD ---");
        try {
            yield buildSiteFromJson(payload);
            currentProgress = totalSteps; // Ensure 100% on success
            updateProgressBar();
            showToast("Site structure built successfully!", "success");
        }
        catch (e) {
            showError(`Build failed: ${(_a = e === null || e === void 0 ? void 0 : e.message) !== null && _a !== void 0 ? _a : e}`);
            showToast("Build failed. Check the error above.", "error");
            log(`Build failed: ${(_b = e === null || e === void 0 ? void 0 : e.message) !== null && _b !== void 0 ? _b : e}`, "error");
        }
        finally {
            setLoading(false);
        }
    });
}
// ------------------------------------
// Webflow API
// ------------------------------------
const WEBFLOW_NATIVE_TAGS = [
    "div",
    "section",
    "header",
    "footer",
    "main",
    "nav",
    "aside",
    "article",
    "address",
    "figure",
    "figcaption",
    "span",
];
// Helper to fetch and upload assets
function uploadAssetFromUrl(url) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (!url || !url.startsWith("http")) {
                console.warn("Skipping asset upload for non-absolute URL:", url);
                return null;
            }
            // 1. Fetch image with basic validation
            const response = yield fetch(url);
            if (!response.ok) {
                throw new Error(`Failed to fetch image: ${response.status} ${response.statusText}`);
            }
            const blob = yield response.blob();
            if (blob.size === 0) {
                throw new Error("Fetched image blob is empty (0 bytes).");
            }
            // 2. Derive a valid file name with extension
            const mimeType = blob.type || "image/png";
            let ext = "png";
            if (mimeType.includes("jpeg") || mimeType.includes("jpg"))
                ext = "jpg";
            else if (mimeType.includes("svg"))
                ext = "svg";
            else if (mimeType.includes("webp"))
                ext = "webp";
            const fileName = `img-${Date.now()}.${ext}`;
            // 3. Resilient upload sequence
            // We try multiple patterns to ensure compatibility with different API variants/versions
            try {
                log(`    → Pattern 1: Uploading File object (${fileName})...`);
                const file = new File([blob], fileName, { type: mimeType });
                return yield webflow.createAsset(file);
            }
            catch (err1) {
                try {
                    log(`    → Pattern 2: Uploading as { file } object...`);
                    const file = new File([blob], fileName, { type: mimeType });
                    return yield webflow.createAsset({ file });
                }
                catch (err2) {
                    try {
                        log(`    → Pattern 3: Uploading named Blob directly...`);
                        blob.name = fileName;
                        return yield webflow.createAsset(blob);
                    }
                    catch (err3) {
                        const finalMsg = (err1 === null || err1 === void 0 ? void 0 : err1.message) || (err3 === null || err3 === void 0 ? void 0 : err3.message) || "All upload patterns failed";
                        log(`    ✕ Asset upload failed: ${finalMsg}`, "error");
                        webflow.notify({ type: "Error", message: `Asset Sync Error: ${finalMsg}` });
                        throw err1;
                    }
                }
            }
        }
        catch (err) {
            console.warn(`Could not upload asset from ${url}:`, err);
            return null;
        }
    });
}
function getPresetForType(node) {
    var _a;
    const tag = (_a = node.tag) === null || _a === void 0 ? void 0 : _a.toLowerCase();
    // 1. Prioritize explicit Webflow types
    switch (node.type) {
        case "Heading":
            return webflow.elementPresets.Heading;
        case "Paragraph":
            return webflow.elementPresets.Paragraph;
        case "Link": {
            // If it has children (like an icon + text), use LinkBlock
            if (node.children && node.children.length > 0)
                return webflow.elementPresets.LinkBlock;
            // If it only has text, a standard Link (Text Link) is much better
            return (webflow.elementPresets.Link || webflow.elementPresets.LinkBlock);
        }
        case "Image":
            return webflow.elementPresets.Image;
        case "HtmlEmbed":
            return (webflow.elementPresets.HtmlEmbed ||
                webflow.elementPresets.Embed ||
                webflow.elementPresets.HTMLEmbed ||
                webflow.elementPresets.Html ||
                webflow.elementPresets.EmbedCode ||
                webflow.elementPresets.CodeEmbed ||
                webflow.elementPresets.EmbedElement);
        case "List":
            return (webflow.elementPresets.List ||
                webflow.elementPresets.ListElement);
        case "ListItem":
            return (webflow.elementPresets.ListItem ||
                webflow.elementPresets.ListItemElement);
    }
    // 2. Map tags to native presets
    if (tag === "ul" || tag === "ol")
        return webflow.elementPresets.List;
    if (tag === "li")
        return webflow.elementPresets.ListItem;
    // 2. Custom attributes check for Block types
    // Allow common attributes that native Webflow elements support
    const allowedAttrs = [
        "id",
        "class",
        "style",
        "src",
        "href",
        "alt",
        "target",
        "loading",
    ];
    const hasCustomAttributes = Object.keys(node.attributes || {}).some((k) => !allowedAttrs.includes(k));
    if (hasCustomAttributes &&
        !["div", "section", "header", "footer", "main"].includes(tag || "")) {
        return webflow.elementPresets.DOM;
    }
    // 3. Fallback logic for Blocks
    // Span should be a DOM element (so it supports setTextContent and 'span' tag)
    if (tag === "span")
        return webflow.elementPresets.DOM;
    // Default to DivBlock for standard containers
    if (!tag || tag === "div" || WEBFLOW_NATIVE_TAGS.includes(tag)) {
        return webflow.elementPresets.DivBlock;
    }
    if (node.children && node.children.length > 0) {
        return webflow.elementPresets.DivBlock;
    }
    return webflow.elementPresets.DOM;
}
// matchesComplexSelector() removed — complex selectors are pre-resolved
// into node.inlineStyles by the backend CLI. No runtime tree walking needed.
/**
 * Robustly adds an element even if the user has a non-container selected.
 * If append is not supported, it tries to add as a sibling (after).
 */
function smartAppend(parentNode, preset) {
    return __awaiter(this, void 0, void 0, function* () {
        if (typeof parentNode.append === "function") {
            return yield parentNode.append(preset);
        }
        if (typeof parentNode.after === "function") {
            log(`    ⚠ Selection (${parentNode.type}) doesn't support children. Adding as sibling instead.`, "warn");
            return yield parentNode.after(preset);
        }
        // Try moving up one level
        if (typeof parentNode.getParent === "function") {
            const realParent = yield parentNode.getParent();
            if (realParent) {
                log(`    ⚠ Selection not a container. Moving up to ${realParent.type}...`, "info");
                return yield smartAppend(realParent, preset);
            }
        }
        throw new Error(`Current selection (${parentNode.type}) cannot have children or siblings.`);
    });
}
function buildElementTree(parentNode_1, rawNodeData_1) {
    return __awaiter(this, arguments, void 0, function* (parentNode, rawNodeData, isLegacy = false) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j;
        // Normalize text: handle array of lines (literal string format) from backend
        const text = Array.isArray(rawNodeData.text)
            ? rawNodeData.text.join("\n")
            : rawNodeData.text;
        const nodeData = Object.assign(Object.assign({}, rawNodeData), { text: text });
        const preset = getPresetForType(nodeData);
        let element;
        try {
            // ------------------------------------
            // Create Element
            // ------------------------------------
            // Use direct append for immediate access to the element reference
            if (!preset) {
                log(`    ✕ Unsupported node type or empty preset for type: ${nodeData.type}`, "error");
                return;
            }
            // ------------------------------------
            // HtmlEmbed Wrapping Logic
            // ------------------------------------
            let targetParent = parentNode;
            if (nodeData.type === "HtmlEmbed") {
                try {
                    log(`    [EMBED] Creating wrapper div.htmlembed...`);
                    const wrapper = yield smartAppend(parentNode, webflow.elementPresets.DivBlock);
                    let embedStyle = yield webflow.getStyleByName("htmlembed");
                    if (!embedStyle) {
                        try {
                            embedStyle = yield webflow.createStyle("htmlembed");
                        }
                        catch (e) {
                            // Fallback if creation fails
                        }
                    }
                    if (embedStyle)
                        yield wrapper.setStyles([embedStyle]);
                    targetParent = wrapper;
                }
                catch (wrapErr) {
                    log(`    ⚠ Failed to create wrapper div: ${wrapErr.message}. Proceeding without wrapper.`, "warn");
                }
            }
            element = yield smartAppend(targetParent, preset);
            if (!element) {
                console.error("Failed to create element for node:", nodeData);
                return;
            }
            // ------------------------------------
            // HtmlEmbed: Re-fetch fresh reference
            // ------------------------------------
            // The element object returned from append() is a lightweight "creation receipt"
            // that doesn't expose the full HtmlEmbed API (e.g. setHtml is missing).
            // Webflow auto-selects the newly appended element, so getSelectedElement()
            // returns the fully-initialized instance with the complete method surface.
            if (nodeData.type === "HtmlEmbed") {
                try {
                    const fresh = yield webflow.getSelectedElement();
                    if (fresh && fresh.type === "HtmlEmbed") {
                        element = fresh;
                        log(`    [EMBED] Re-fetched fresh element reference (type: ${fresh.type})`, "info");
                    }
                }
                catch (e) {
                    log(`    [EMBED] Could not re-fetch element: ${e.message}. Using original reference.`, "warn");
                }
            }
            // ------------------------------------
            // List Handling: Empty default items
            // ------------------------------------
            // Webflow adds 3 default ListItems to a new List. We must clear them first.
            if (nodeData.type === "List" && element.getChildren) {
                try {
                    const defaultChildren = yield element.getChildren();
                    if (defaultChildren && defaultChildren.length > 0) {
                        log(`    [LIST] Clearing ${defaultChildren.length} default items...`);
                        for (const child of defaultChildren) {
                            yield child.remove();
                        }
                    }
                }
                catch (e) {
                    console.warn("Failed to clear default list children:", e);
                }
            }
            // ------------------------------------
            // Set Tag
            // ------------------------------------
            let tagToSet = (_a = nodeData.tag) === null || _a === void 0 ? void 0 : _a.toLowerCase();
            // Skip setting 'span' tag for non-DOM elements as it's not a valid top-level block tag for DivBlocks
            if (tagToSet === "span" && element.type !== "DOM")
                tagToSet = undefined;
            // If we fell back to DivBlock for a Paragraph/Heading with children, ensure it maintains semantic tag
            if (!tagToSet && (nodeData.children && nodeData.children.length > 0)) {
                if (nodeData.type === "Paragraph")
                    tagToSet = "p";
                if (nodeData.type === "Heading")
                    tagToSet = ((_b = nodeData.tag) === null || _b === void 0 ? void 0 : _b.toLowerCase()) || "h2";
            }
            // Skip setting tag for specialized elements like HtmlEmbed which manage their own internal tag/content
            // Determine if we are using a specialized preset or falling back to a custom DOM element
            const isSpecializedHtmlEmbed = nodeData.type === "HtmlEmbed" && element.type !== "DOM";
            // Skip setting tag for specialized elements like HtmlEmbed which manage their own internal tag/content.
            // However, if we fell back to a custom DOM element, we MUST set the tag.
            if (tagToSet && element.setTag && !isSpecializedHtmlEmbed) {
                yield element.setTag(tagToSet);
            }
            // ------------------------------------
            // Text Content
            // ------------------------------------
            // Specialized elements (like HtmlEmbed) set their content via settings, not textContent.
            // If we fell back to a custom DOM element (as suggested by Webflow Designer), we use textContent.
            if (element.setTextContent && !isSpecializedHtmlEmbed) {
                // Clear default text (like Lorem Ipsum) for text-centric types if no text is provided,
                // or if text is explicitly provided as an empty string.
                const isTextType = ["Paragraph", "Heading", "Link"].includes(nodeData.type) ||
                    nodeData.tag === "p" ||
                    nodeData.tag === "span";
                const shouldSetText = nodeData.text !== undefined || isTextType;
                if (shouldSetText) {
                    yield element.setTextContent(nodeData.text || "");
                }
            }
            // ------------------------------------
            // Attributes & ID
            // ------------------------------------
            if (nodeData.id) {
                if (element.setCustomAttribute) {
                    yield element.setCustomAttribute("id", nodeData.id);
                }
                else if (element.setAttribute) {
                    yield element.setAttribute("id", nodeData.id);
                }
            }
            // Process custom attributes
            if (nodeData.attributes &&
                Object.keys(nodeData.attributes).length > 0) {
                for (const [key, value] of Object.entries(nodeData.attributes)) {
                    if (element.setCustomAttribute) {
                        yield element.setCustomAttribute(key, value);
                    }
                    else if (element.setAttribute) {
                        yield element.setAttribute(key, value);
                    }
                }
            }
            // ------------------------------------
            // Classes (Webflow Styles / Combo Classes)
            // ------------------------------------
            const styleRefs = [];
            const classes = [...(nodeData.classes || [])];
            // Merge styles: node's own styles + backend-inlined complex selector styles
            const nodeStyles = Object.assign(Object.assign({}, (nodeData.styles || {})), (nodeData.inlineStyles || {}));
            const hasStylesToApply = Object.keys(nodeStyles).length > 0;
            const hasPseudoStyles = nodeData.inlinePseudoStyles &&
                Object.keys(nodeData.inlinePseudoStyles).length > 0;
            // If the element has styles but no classes, auto-generate a class name
            if ((hasStylesToApply || hasPseudoStyles) && classes.length === 0) {
                const tagBase = nodeData.tag || nodeData.type.toLowerCase() || "element";
                classes.push(`${tagBase}-style`);
            }
            if (classes.length > 0 && element.setStyles) {
                let currentParent = null;
                const cleanClasses = classes.filter((c) => c && c.trim().length > 0);
                for (const className of cleanClasses) {
                    let style = yield webflow.getStyleByName(className);
                    if (style) {
                        const parent = yield style.getParent();
                        if ((parent === null || parent === void 0 ? void 0 : parent.id) !== (currentParent === null || currentParent === void 0 ? void 0 : currentParent.id))
                            style = null;
                    }
                    if (!style) {
                        try {
                            style = yield webflow.createStyle(className, currentParent ? { parent: currentParent } : {});
                        }
                        catch (e) {
                            console.warn(`Could not create style ${className}:`, e);
                        }
                    }
                    if (style) {
                        styleRefs.push(style);
                        currentParent = style;
                    }
                }
                if (styleRefs.length > 0) {
                    try {
                        yield element.setStyles([...styleRefs]);
                    }
                    catch (e) {
                        console.error("Failed to apply style chain:", e);
                    }
                }
            }
            // ------------------------------------
            // Apply Properties to the primary class
            // ------------------------------------
            if (styleRefs.length > 0) {
                const primaryStyle = styleRefs[styleRefs.length - 1];
                if (hasStylesToApply) {
                    yield applyStyleProperties(primaryStyle, nodeStyles, undefined, isLegacy);
                }
                if (hasPseudoStyles) {
                    for (const [pseudo, pseudoProps] of Object.entries(nodeData.inlinePseudoStyles || {})) {
                        yield applyStyleProperties(primaryStyle, pseudoProps, { pseudo }, isLegacy);
                    }
                }
            }
            // ------------------------------------
            // Specialized Elements (Image, Link)
            // ------------------------------------
            const src = (_c = nodeData.attributes) === null || _c === void 0 ? void 0 : _c.src;
            const href = (_d = nodeData.attributes) === null || _d === void 0 ? void 0 : _d.href;
            if (nodeData.type === "Image") {
                if (src && element.setAsset) {
                    log(`    [IMAGE] Uploading asset: ${src}...`);
                    const asset = yield uploadAssetFromUrl(src);
                    if (asset) {
                        yield element.setAsset(asset);
                        log(`    ✓ Asset uploaded successfully`, "success");
                    }
                    else {
                        log(`    ⚠ Asset upload failed, falling back to src attribute`, "warn");
                        yield ((_e = element.setCustomAttribute) === null || _e === void 0 ? void 0 : _e.call(element, "src", src));
                    }
                }
                else if (src && element.setAttribute) {
                    yield element.setAttribute("src", src);
                }
                // Handle Alt Text
                if (((_f = nodeData.attributes) === null || _f === void 0 ? void 0 : _f.alt) && element.setAltText) {
                    yield element.setAltText(String(nodeData.attributes.alt));
                }
            }
            if (nodeData.type === "Link") {
                // Handle Href
                if (href) {
                    if (element.setSettings) {
                        yield element.setSettings("url", href);
                    }
                    else if (element.setAttribute) {
                        yield element.setAttribute("href", href);
                    }
                    else if (element.setCustomAttribute) {
                        yield element.setCustomAttribute("href", href);
                    }
                }
                // Handle Target
                if (((_g = nodeData.attributes) === null || _g === void 0 ? void 0 : _g.target) && element.setTarget) {
                    yield element.setTarget(nodeData.attributes.target);
                }
            }
            // Special handling for data-asset: Upload external URLs to Webflow assets
            if (((_h = nodeData.attributes) === null || _h === void 0 ? void 0 : _h["data-asset"]) && element.setCustomAttribute) {
                const asset = yield uploadAssetFromUrl(nodeData.attributes["data-asset"]);
                if (asset) {
                    const assetUrl = yield asset.getUrl();
                    yield element.setCustomAttribute("data-asset", assetUrl);
                }
            }
            // ------------------------------------
            // Specialized Elements (HtmlEmbed)
            // ------------------------------------
            if (nodeData.type === "HtmlEmbed") {
                if (nodeData.text) {
                    let success = false;
                    if (element.type === "DOM") {
                        log(`    [EMBED] Custom DOM fallback detected. Content applied via tag/textContent.`, "info");
                    }
                    else {
                        log(`    [EMBED] Attempting automated internal content injection (Type: ${element.type})...`);
                        // Attempt multiple injection patterns for HtmlEmbed to bypass V2 API restrictions
                        const patterns = [
                            { name: "setHtml", fn: (el, val) => el.setHtml(val) },
                            { name: "setHtmlContent", fn: (el, val) => el.setHtmlContent(val) },
                            { name: "setSettings({html})", fn: (el, val) => el.setSettings({ html: val }) },
                            { name: "setSettings({code})", fn: (el, val) => el.setSettings({ code: val }) },
                            { name: "setSettings('html')", fn: (el, val) => el.setSettings("html", val) },
                            { name: "setSettings('code')", fn: (el, val) => el.setSettings("code", val) },
                        ];
                        for (const pattern of patterns) {
                            if (success)
                                break;
                            try {
                                if (typeof element[pattern.name.split('(')[0]] === "function") {
                                    yield pattern.fn(element, nodeData.text);
                                    success = true;
                                    log(`    ✓ Embed content injected via ${pattern.name}`, "success");
                                }
                            }
                            catch (err) {
                                // Silently try next pattern
                            }
                        }
                        // If all else fails
                        if (!success) {
                            log(`    ⚠ Automated injection blocked by Webflow API. Generating visible raw-code text box on canvas for manual copy...`, "warn");
                            try {
                                // Webflow's DOM primitive allows <textarea> which preserves whitespace perfectly 
                                // entirely avoiding the data-attribute stringification issue.
                                // Use targetParent (the wrapper) to keep it contained
                                const textArea = yield targetParent.append(webflow.elementPresets.DOM);
                                if (textArea) {
                                    yield textArea.setTag("textarea");
                                    // Webflow v2's primitive DOM sometimes blocks attributes; sticking to content.
                                    yield textArea.setTextContent(nodeData.text);
                                    log(`    👉 SOLUTION: Copy the code directly from the text area that just appeared on your canvas, paste it into the HTML Embed setting, and then delete the box.`, "info");
                                }
                            }
                            catch (textareaErr) {
                                log(`    ✕ Failed to create visual textarea fallback: ${textareaErr.message}`, "error");
                                // Attempt final data-attribute fallback if supported on the original element
                                if (typeof element.setCustomAttribute === 'function') {
                                    yield element.setCustomAttribute("data-code-source", nodeData.text);
                                }
                            }
                        }
                    }
                }
            }
            // Children (Recursive)
            // ------------------------------------
            incrementProgress();
            if (nodeData.children && nodeData.children.length > 0) {
                for (const child of nodeData.children) {
                    yield buildElementTree(element, child, isLegacy);
                }
            }
        }
        catch (err) {
            const label = ((_j = nodeData.classes) === null || _j === void 0 ? void 0 : _j[0]) || nodeData.tag || nodeData.type;
            log(`    ✕ Error building node [${label}]: ${err.message || err}`, "error");
            console.error("Error building node:", nodeData, err);
        }
    });
}
function resolveValueForCreate(type, serVal) {
    if (!serVal || serVal.value === null || serVal.value === undefined) {
        switch (type) {
            case "Color":
                return "#000000";
            case "Size":
                return { unit: "px", value: 0 };
            case "FontFamily":
                return "Inter";
            case "Number":
                return 0;
            case "Percentage":
                return 0;
            default:
                return "#000000";
        }
    }
    if (serVal.isCustom && serVal.customValue) {
        return { type: "custom", value: serVal.customValue };
    }
    return serVal.value;
}
function pasteCollections(collections) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        log(`Found ${collections.length} variable collection${collections.length !== 1 ? "s" : ""}. Importing...`);
        // Pre-fetch all existing collections once
        const existingCollections = yield webflow.getAllVariableCollections();
        const existingCollectionMap = new Map();
        for (const existing of existingCollections) {
            const n = yield existing.getName();
            existingCollectionMap.set(n, existing);
        }
        for (const serializedCol of collections) {
            log(`Processing collection: "${serializedCol.name}"`);
            let targetCol = (_a = existingCollectionMap.get(serializedCol.name)) !== null && _a !== void 0 ? _a : null;
            if (targetCol) {
                log(`Collection "${serializedCol.name}" already exists — reusing.`, "warn");
            }
            if (!targetCol) {
                try {
                    targetCol = yield webflow.createVariableCollection(serializedCol.name);
                    log(`Created collection: "${serializedCol.name}"`);
                }
                catch (err) {
                    console.error(`Failed to create collection "${serializedCol.name}"`, err);
                    log(`Failed to create collection "${serializedCol.name}"`, "error");
                    continue;
                }
            }
            const modeRefs = {};
            const existingModes = yield targetCol.getAllVariableModes();
            for (const existingMode of existingModes) {
                const modeName = yield existingMode.getName();
                modeRefs[modeName] = existingMode;
            }
            const baseModeName = serializedCol.modes.length > 0
                ? serializedCol.modes[0].name
                : "Default";
            for (let i = 0; i < serializedCol.modes.length; i++) {
                const modeName = serializedCol.modes[i].name;
                if (modeName === baseModeName)
                    continue;
                if (!modeRefs[modeName]) {
                    try {
                        const newMode = yield targetCol.createVariableMode(modeName);
                        modeRefs[modeName] = newMode;
                        log(`Created mode: "${modeName}"`);
                    }
                    catch (err) {
                        console.error(`Failed to create mode "${modeName}"`, err);
                        log(`Failed to create mode "${modeName}"`, "error");
                    }
                }
            }
            // Pre-fetch all variables in THIS collection to avoid O(n) lookups
            const varsInCol = yield targetCol.getAllVariables();
            const varMap = new Map();
            for (const v of varsInCol) {
                const n = yield v.getName();
                varMap.set(n, v);
            }
            const totalVars = serializedCol.variables.length;
            log(`Importing ${totalVars} variable${totalVars !== 1 ? "s" : ""} into "${serializedCol.name}"...`);
            let varsDone = 0;
            let varsSkipped = 0;
            // Process variables in chunks to avoid IPC overload
            const CHUNK_SIZE = 10;
            for (let i = 0; i < serializedCol.variables.length; i += CHUNK_SIZE) {
                const chunk = serializedCol.variables.slice(i, i + CHUNK_SIZE);
                yield Promise.all(chunk.map((serializedVar) => __awaiter(this, void 0, void 0, function* () {
                    const existing = varMap.get(serializedVar.name);
                    if (existing) {
                        try {
                            // For existing variables, we still need metadata for the cache
                            // We can do this in parallel within the chunk
                            const [binding, rawValue, cssName] = yield Promise.all([
                                existing.getBinding(),
                                existing.get(),
                                typeof existing.getCSSName === "function"
                                    ? existing.getCSSName()
                                    : Promise.resolve(`--${serializedVar.name}`),
                            ]);
                            const meta = {
                                variable: existing,
                                binding,
                                rawValue,
                                type: serializedVar.type,
                                cssName,
                            };
                            variableCache.set(serializedVar.name, meta);
                            variableCache.set(`--${serializedVar.name}`, meta);
                        }
                        catch (e) {
                            console.warn(`Could not get metadata for existing variable ${serializedVar.name}`);
                            variableCache.set(serializedVar.name, {
                                variable: existing,
                                type: serializedVar.type,
                            });
                        }
                        varsSkipped++;
                        return;
                    }
                    try {
                        const baseSerVal = serializedVar.values[baseModeName] ||
                            Object.values(serializedVar.values)[0];
                        const defaultValue = resolveValueForCreate(serializedVar.type, baseSerVal);
                        const modesMap = {};
                        for (const serializedMode of serializedCol.modes) {
                            const modeName = serializedMode.name;
                            if (modeName === baseModeName)
                                continue;
                            const modeRef = modeRefs[modeName];
                            if (modeRef) {
                                const modeSerVal = serializedVar.values[modeName];
                                if (modeSerVal !== undefined) {
                                    modesMap[modeRef.id] =
                                        resolveValueForCreate(serializedVar.type, modeSerVal);
                                }
                            }
                        }
                        let webflowVar;
                        const name = serializedVar.name;
                        const modes = Object.keys(modesMap).length > 0
                            ? modesMap
                            : undefined;
                        switch (serializedVar.type) {
                            case "Color":
                                webflowVar =
                                    yield targetCol.createColorVariable(name, defaultValue, modes);
                                break;
                            case "Size":
                                webflowVar = yield targetCol.createSizeVariable(name, defaultValue, modes);
                                break;
                            case "FontFamily":
                                webflowVar =
                                    yield targetCol.createFontFamilyVariable(name, defaultValue, modes);
                                break;
                            case "Number":
                                webflowVar =
                                    yield targetCol.createNumberVariable(name, defaultValue, modes);
                                break;
                            case "Percentage":
                                webflowVar =
                                    yield targetCol.createPercentageVariable(name, defaultValue, modes);
                                break;
                        }
                        if (webflowVar) {
                            try {
                                const [binding, rawValue, cssName] = yield Promise.all([
                                    webflowVar.getBinding(),
                                    webflowVar.get(),
                                    typeof webflowVar.getCSSName ===
                                        "function"
                                        ? webflowVar.getCSSName()
                                        : Promise.resolve(`--${name}`),
                                ]);
                                const meta = {
                                    variable: webflowVar,
                                    binding,
                                    rawValue,
                                    type: serializedVar.type,
                                    cssName,
                                };
                                variableCache.set(name, meta);
                                variableCache.set(`--${name}`, meta);
                            }
                            catch (e) {
                                console.warn(`Could not get metadata for new variable ${name}`);
                                variableCache.set(name, {
                                    variable: webflowVar,
                                    type: serializedVar.type,
                                });
                            }
                        }
                        varsDone++;
                    }
                    catch (err) {
                        console.error(`Failed to create variable "${serializedVar.name}":`, err);
                        log(`Failed to create variable "${serializedVar.name}"`, "error");
                    }
                })));
                // Each variable processed (done or skipped) increments progress
                incrementProgress(chunk.length);
                // Small breather between chunks to keep the UI responsive and IPC alive
                if (i + CHUNK_SIZE < serializedCol.variables.length) {
                    yield new Promise((resolve) => setTimeout(resolve, 50));
                }
            }
            const skippedMsg = varsSkipped > 0 ? `, ${varsSkipped} already existed` : "";
            log(`✓ ${varsDone} variable${varsDone !== 1 ? "s" : ""} imported${skippedMsg}`, "success");
        }
    });
}
/**
 * Synchronizes the internal variable cache with existing variables in the Webflow project.
 * This ensures that modular JSON segments (which might lack the collections array)
 * can still resolve CSS variables back to their Webflow UI equivalent.
 */
function syncVariableCacheFromWebflow() {
    return __awaiter(this, void 0, void 0, function* () {
        log("Syncing variables from Webflow project...");
        try {
            const collections = yield webflow.getAllVariableCollections();
            let totalFound = 0;
            for (const col of collections) {
                const variables = yield col.getAllVariables();
                for (const v of variables) {
                    try {
                        const [name, binding, rawValue, cssName] = yield Promise.all([
                            v.getName(),
                            v.getBinding(),
                            v.get(),
                            typeof v.getCSSName === "function" ? v.getCSSName() : Promise.resolve(null),
                        ]);
                        const meta = {
                            variable: v,
                            binding,
                            rawValue,
                            type: v.type || "Color",
                            cssName: cssName || `--${name}`,
                        };
                        // Store by CSS name (e.g. --color-primary)
                        const vCssName = (cssName || `--${name}`).trim();
                        variableCache.set(vCssName, meta);
                        // Also store by simple name but prefixed with -- just in case
                        const cleanName = name.trim().toLowerCase().replace(/\s+/g, "-");
                        variableCache.set(`--${cleanName}`, meta);
                        totalFound++;
                    }
                    catch (e) {
                        // Individual variable failure shouldn't stop the whole sync
                    }
                }
            }
            log(`✓ Discovered ${totalFound} existing variables in project`, "success");
        }
        catch (err) {
            log(`Failed to sync existing variables: ${err.message}`, "warn");
        }
    });
}
function buildSiteFromJson(payload) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const selected = yield webflow.getSelectedElement();
        if (!selected) {
            yield webflow.notify({
                type: "Error",
                message: "Please select an element (e.g. Body) to paste into.",
            });
            throw new Error("No element selected in the Designer.");
        }
        // Detect JSON version — v2 is pre-normalized by the backend
        const isLegacy = !payload.__meta || payload.__meta.version < 2;
        if (isLegacy) {
            log("⚠ Legacy JSON detected (v1) — enabling runtime normalization shim.", "warn");
        }
        else {
            log(`JSON v${payload.__meta.version} detected — pre-normalized. Skipping runtime transforms.`);
        }
        log("Starting build...");
        variableCache.clear();
        // Step 0: Sync from existing project variables (enables cross-JSON variable resolution)
        yield syncVariableCacheFromWebflow();
        // Step 1: Variables
        if (payload.collections && payload.collections.length > 0) {
            const totalVars = payload.collections.reduce((sum, c) => sum + c.variables.length, 0);
            totalSteps += totalVars;
            webflow.notify({
                type: "Info",
                message: `Importing ${totalVars} variables...`,
            });
            yield pasteCollections(payload.collections);
            webflow.notify({ type: "Success", message: "✓ Variables imported" });
        }
        else {
            log("No variable collections found — skipping.", "warn");
        }
        // Step 2: Global Styles
        const globalStyles = payload.globalStyles || payload.styles;
        if (globalStyles && Object.keys(globalStyles).length > 0) {
            const classSelectors = Object.keys(globalStyles).filter((s) => s.startsWith(".") && !s.includes(" "));
            totalSteps += classSelectors.length;
            webflow.notify({
                type: "Info",
                message: "Applying root global styles...",
            });
            yield applyGlobalStyles(globalStyles, isLegacy);
        }
        // Step 3: DOM Nodes
        let pages = (_a = payload.pages) !== null && _a !== void 0 ? _a : [];
        // If no pages but we have nodes at the root, treat it as a single-page/section payload
        if (pages.length === 0 && payload.nodes && payload.nodes.length > 0) {
            log("Detected single-section payload (nodes at root).");
            pages = [
                {
                    nodes: payload.nodes,
                    globalStyles: payload.globalStyles,
                    styles: payload.styles,
                },
            ];
        }
        let totalNodes = 0;
        function countAllNodes(nodes) {
            let count = nodes.length;
            for (const n of nodes) {
                if (n.children)
                    count += countAllNodes(n.children);
            }
            return count;
        }
        pages.forEach((p) => {
            var _a;
            totalNodes += countAllNodes((_a = p.nodes) !== null && _a !== void 0 ? _a : []);
        });
        totalSteps += totalNodes;
        if (totalNodes === 0) {
            log("No nodes found to build — skipping building DOM.", "warn");
            return;
        }
        log(`Building ${pages.length} page${pages.length !== 1 ? "s" : ""} with ${totalNodes} total nodes...`);
        webflow.notify({
            type: "Info",
            message: `Building DOM (${totalNodes} total nodes)...`,
        });
        for (let pi = 0; pi < pages.length; pi++) {
            const page = pages[pi];
            const nodes = (_b = page.nodes) !== null && _b !== void 0 ? _b : [];
            log(`Page ${pi + 1}/${pages.length}: building ${nodes.length} root node${nodes.length !== 1 ? "s" : ""}...`);
            for (let ni = 0; ni < nodes.length; ni++) {
                yield buildElementTree(selected, nodes[ni], isLegacy);
            }
            // Page-level styles (less common, but supported)
            const pageStyles = page.globalStyles || page.styles;
            if (pageStyles && Object.keys(pageStyles).length > 0) {
                log(`Applying page-level styles for "${page.name}"...`);
                yield applyGlobalStyles(pageStyles, isLegacy);
            }
            log(`✓ Page ${pi + 1} complete`, "success");
        }
        log("✓ Build complete!", "success");
        yield webflow.notify({ type: "Success", message: "Site structure built!" });
    });
}
// ------------------------------------
// UI helpers
// ------------------------------------
function setLoading(on) {
    buildBtn.disabled = on;
    spinner.classList.toggle("show", on);
    btnLabel.textContent = on ? "Building…" : "Build Site";
    if (!on) {
        // Re-enable the clear button and finalise the log when done
        const clearBtn = document.getElementById("clear-log-btn");
        if (clearBtn)
            clearBtn.disabled = false;
    }
}
function showError(msg) {
    errorBox.textContent = msg;
    errorBox.classList.add("show");
}
function hideError() {
    errorBox.classList.remove("show");
}
let toastTimer = null;
function showToast(msg, type) {
    const toast = document.getElementById("toast");
    toast.textContent = msg;
    toast.className = `toast toast-${type} show`;
    if (toastTimer)
        clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
        toast.classList.remove("show");
    }, 3500);
}
// ------------------------------------
// Boot
// ------------------------------------
document.addEventListener("DOMContentLoaded", init);
